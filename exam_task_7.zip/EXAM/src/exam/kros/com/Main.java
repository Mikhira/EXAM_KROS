package exam.kros.com;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

// створення аннотації
@Retention(RetentionPolicy.RUNTIME)
@interface Annotation {

    public String key();

    public String value();
}

class GFG {

    // викликати Анотації для методу та передавання значення для анотації
    @Annotation(key = "AvengersLeader", value = "CaptainAmerica")
    public static Annotation getCustomAnnotation() {
        Method method = null;
        Annotation anno = null;
        try {

            // створення об’єкта класу для імені класу GFG
            Class c = GFG.class;

            // отримання ім'я методу getCustomAnnotation як об'єкт Method
            Method[] methods = c.getMethods();
            for (Method m : methods) {
                if (m.getName().equals("getCustomAnnotation"))
                    method = m;
            }

            // отримання анотацію методу m шляхом передачі
            // Об'єкту класу анотацій як параметр
            anno = method.getAnnotation(Annotation.class);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return anno;
    }

    public static void main(String[] args) throws IOException {
        Annotation annotation = getCustomAnnotation();

        appendToFile.append(annotation);
    }

    static class appendToFile {

        public static void append(Annotation annotation) throws IOException {

            BufferedWriter writer = new BufferedWriter(
                    new FileWriter("/home/mykhailo/test.txt", true));

            writer.newLine();
            writer.write(annotation.toString());
            writer.close();
        }
    }
}




